from setuptools import setup

setup(name='predictiveanalytics',
      version='0.0.2',
      description='Tools and Algorithms used for Predictive Analytics and Machine Learning',
      url='http://github.com/bawdiest/predictiveanalytics',
      author='bawdiest',
      author_email='com@mikmak.cc',
      license='MIT',
      packages=['predictiveanalytics'],
      zip_safe=False)
